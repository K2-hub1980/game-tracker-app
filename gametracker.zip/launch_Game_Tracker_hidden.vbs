Set WshShell = CreateObject("WScript.Shell")
WshShell.Run "pythonw.exe ""/mnt/data/Game_Tracker_v10.pyw""", 0, False
