import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3, os, re, urllib.request, urllib.parse, json, threading, subprocess
from pathlib import Path

APP = Path(__file__).resolve().parent
DB = APP / "games.db"
db = sqlite3.connect(DB, check_same_thread=False)
db.execute("""CREATE TABLE IF NOT EXISTS games(
id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT UNIQUE NOT NULL,
status TEXT NOT NULL DEFAULT 'Not Started', progress INTEGER NOT NULL DEFAULT 0,
notes TEXT NOT NULL DEFAULT '', source TEXT NOT NULL DEFAULT 'Manual',
path TEXT NOT NULL DEFAULT '', steam_appid TEXT NOT NULL DEFAULT '',
achievements_total INTEGER NOT NULL DEFAULT 0, achievements_unlocked INTEGER NOT NULL DEFAULT 0,
completion_method TEXT NOT NULL DEFAULT 'Manual')""")
db.commit()
cols={r[1] for r in db.execute("PRAGMA table_info(games)")}
for c,d in [("steam_appid","TEXT NOT NULL DEFAULT ''"),("achievements_total","INTEGER NOT NULL DEFAULT 0"),
            ("achievements_unlocked","INTEGER NOT NULL DEFAULT 0"),("completion_method","TEXT NOT NULL DEFAULT 'Manual'")]:
    if c not in cols: db.execute(f"ALTER TABLE games ADD COLUMN {c} {d}")
db.commit()

db.execute("""CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT NOT NULL DEFAULT '')""")
db.commit()

root=tk.Tk(); root.title("Game Tracker"); root.geometry("1240x760"); root.minsize(1000,620)
style=ttk.Style()
try: style.theme_use("clam")
except: pass
THEMES={"dark":{"BG":"#0f1117","PANEL":"#171a23","PANEL2":"#1e2330","TEXT":"#f2f4f8","MUTED":"#9aa4b2","ACCENT":"#7c5cff","ACCENT_H":"#9478ff","BORDER":"#2a3040"},"light":{"BG":"#f4f6fa","PANEL":"#ffffff","PANEL2":"#e8ecf3","TEXT":"#1e2430","MUTED":"#697386","ACCENT":"#6846e8","ACCENT_H":"#7e63ec","BORDER":"#d2d8e3"}}
def get_setting(key,default=""):
    r=db.execute("SELECT value FROM settings WHERE key=?",(key,)).fetchone(); return r[0] if r else default
def set_setting(key,value):
    db.execute("INSERT OR REPLACE INTO settings(key,value) VALUES(?,?)",(key,value)); db.commit()
current_theme=get_setting("theme","dark")
if current_theme not in THEMES: current_theme="dark"
BG=PANEL=PANEL2=TEXT=MUTED=ACCENT=ACCENT_H=BORDER=""
def apply_theme(name):
    global current_theme,BG,PANEL,PANEL2,TEXT,MUTED,ACCENT,ACCENT_H,BORDER
    current_theme=name if name in THEMES else "dark"; c=THEMES[current_theme]
    BG,PANEL,PANEL2,TEXT,MUTED,ACCENT,ACCENT_H,BORDER=[c[k] for k in ("BG","PANEL","PANEL2","TEXT","MUTED","ACCENT","ACCENT_H","BORDER")]
    root.configure(bg=BG)
    style.configure("TFrame",background=BG); style.configure("TLabel",background=BG,foreground=TEXT,font=("Segoe UI",10))
    style.configure("Title.TLabel",background=BG,foreground=TEXT,font=("Segoe UI",25,"bold")); style.configure("Subtitle.TLabel",background=BG,foreground=MUTED,font=("Segoe UI",10)); style.configure("Stats.TLabel",background=BG,foreground=ACCENT_H,font=("Segoe UI",10,"bold"))
    style.configure("TLabelframe",background=PANEL,foreground=TEXT,bordercolor=BORDER); style.configure("TLabelframe.Label",background=PANEL,foreground=TEXT,font=("Segoe UI",11,"bold"))
    style.configure("TButton",background=PANEL2,foreground=TEXT,bordercolor=BORDER,padding=(10,7),font=("Segoe UI",9,"bold")); style.map("TButton",background=[("active",ACCENT),("pressed",ACCENT_H)])
    style.configure("Accent.TButton",background=ACCENT,foreground="#ffffff",padding=(10,8)); style.map("Accent.TButton",background=[("active",ACCENT_H),("pressed",ACCENT)])
    style.configure("TEntry",fieldbackground=PANEL2,foreground=TEXT,insertcolor=TEXT,bordercolor=BORDER,lightcolor=BORDER,darkcolor=BORDER,padding=6)
    style.configure("TCombobox",fieldbackground=PANEL2,foreground=TEXT,selectbackground=ACCENT,selectforeground="#ffffff",bordercolor=BORDER,padding=5); style.map("TCombobox",fieldbackground=[("readonly",PANEL2)],foreground=[("readonly",TEXT)])
    style.configure("Treeview",background=PANEL,fieldbackground=PANEL,foreground=TEXT,bordercolor=BORDER,rowheight=38,font=("Segoe UI",9)); style.configure("Treeview.Heading",background=PANEL2,foreground=MUTED,relief="flat",font=("Segoe UI",9,"bold"),padding=8); style.map("Treeview",background=[("selected",ACCENT)],foreground=[("selected","#ffffff")])
    style.configure("Vertical.TScrollbar",background=PANEL2,troughcolor=BG,bordercolor=BG,arrowcolor=MUTED); style.configure("TNotebook",background=BG,borderwidth=0); style.configure("TNotebook.Tab",background=PANEL2,foreground=MUTED,padding=(14,7),font=("Segoe UI",9,"bold")); style.map("TNotebook.Tab",background=[("selected",ACCENT)],foreground=[("selected","#ffffff")])
    try:
        canvas.configure(bg=BG); notes.configure(bg=PANEL2,fg=TEXT,insertbackground=TEXT,selectbackground=ACCENT,selectforeground="#ffffff")
    except Exception: pass
apply_theme(current_theme)

def launch_game():
    if not sel:
        messagebox.showinfo(
            "Launch Game",
            "Select a game first."
        )
        return

    game = db.execute(
        """
        SELECT name, source, path, steam_appid, notes
        FROM games
        WHERE id=?
        """,
        (sel,)
    ).fetchone()

    if not game:
        messagebox.showwarning(
            "Launch Game",
            "The selected game could not be found."
        )
        return

    game_name, game_source, game_path, steam_appid, game_notes = game

    try:

        # ==========================
        # STEAM
        # ==========================
        if game_source == "Steam":

            if not steam_appid:
                messagebox.showwarning(
                    "Steam",
                    "This game doesn't have a Steam AppID."
                )
                return

            os.startfile(
                f"steam://rungameid/{steam_appid}"
            )

        # ==========================
        # MINECRAFT
        # ==========================
        elif game_source == "Minecraft":

            app_id = (game_path or "").strip()

            if not app_id:
                messagebox.showwarning(
                    "Minecraft",
                    "Minecraft doesn't have a saved Windows App ID.\n\n"
                    "Click 'Scan Minecraft' first."
                )
                return

            try:
                subprocess.Popen(
                    [
                        "explorer.exe",
                        f"shell:AppsFolder\\{app_id}"
                    ]
                )

            except Exception as error:
                messagebox.showerror(
                    "Minecraft Launch Error",
                    f"Couldn't launch Minecraft.\n\n{error}"
                )

        # ==========================
        # ROBLOX
        # ==========================
        elif game_source == "Roblox":

            app_id = (game_path or "").strip()

            if not app_id:
                messagebox.showwarning(
                    "Roblox",
                    "Roblox doesn't have a saved Windows App ID.\n\n"
                    "Click 'Scan Roblox' first."
                )
                return

            # Launch a Microsoft Store / Windows app by AUMID.
            subprocess.Popen(
                [
                    "explorer.exe",
                    f"shell:AppsFolder\\{app_id}"
                ]
            )

        # ==========================
        # BLUESTACKS
        # ==========================
        elif game_source == "BlueStacks":

            package = (game_path or "").strip()

            if not package:
                messagebox.showwarning(
                    "BlueStacks",
                    "This game has no Android package in Install Path."
                )
                return

            bluestacks = Path(
                "C:/Program Files/BlueStacks_nxt/HD-Player.exe"
            )

            if not bluestacks.exists():
                messagebox.showwarning(
                    "BlueStacks",
                    "HD-Player.exe could not be found."
                )
                return

            subprocess.Popen([
                str(bluestacks),
                "--cmd",
                "launchApp",
                "--package",
                package
            ])

        # ==========================
        # MANUAL GAMES
        # ==========================
        else:

            launch_path = (game_path or "").strip()

            if not launch_path:
                messagebox.showwarning(
                    "Launch Game",
                    f"{game_name} doesn't have an Install Path."
                )
                return

            launch_file = Path(launch_path)

            if not launch_file.exists():
                messagebox.showwarning(
                    "Launch Game",
                    "The launch file could not be found:\n\n"
                    + launch_path
                )
                return

            os.startfile(str(launch_file))

    except Exception as error:

        messagebox.showerror(
            "Launch Error",
            f"Couldn't launch {game_name}.\n\n"
            f"Error:\n{error}"
        )

try:
    style.theme_use("clam")
except:
    pass

# ---------- DARK THEME ----------
BG = "#0f1117"
PANEL = "#171a23"
PANEL2 = "#1e2330"
TEXT = "#f2f4f8"
MUTED = "#9aa4b2"
ACCENT = "#7c5cff"
ACCENT_HOVER = "#9478ff"
BORDER = "#2a3040"

root.configure(bg=BG)

style.configure("TFrame", background=BG)

style.configure(
    "TLabel",
    background=BG,
    foreground=TEXT,
    font=("Segoe UI", 10)
)

style.configure(
    "Title.TLabel",
    background=BG,
    foreground=TEXT,
    font=("Segoe UI", 25, "bold")
)

style.configure(
    "Subtitle.TLabel",
    background=BG,
    foreground=MUTED,
    font=("Segoe UI", 10)
)

style.configure(
    "Stats.TLabel",
    background=BG,
    foreground=ACCENT_HOVER,
    font=("Segoe UI", 10, "bold")
)

style.configure(
    "TLabelframe",
    background=PANEL,
    foreground=TEXT,
    bordercolor=BORDER
)

style.configure(
    "TLabelframe.Label",
    background=PANEL,
    foreground=TEXT,
    font=("Segoe UI", 11, "bold")
)

style.configure(
    "TButton",
    background=PANEL2,
    foreground=TEXT,
    bordercolor=BORDER,
    padding=(10, 7),
    font=("Segoe UI", 9, "bold")
)

style.map(
    "TButton",
    background=[
        ("active", ACCENT),
        ("pressed", ACCENT_HOVER)
    ]
)

style.configure(
    "Accent.TButton",
    background=ACCENT,
    foreground="#ffffff",
    padding=(10, 8)
)

style.map(
    "Accent.TButton",
    background=[
        ("active", ACCENT_HOVER),
        ("pressed", ACCENT)
    ]
)

style.configure(
    "TEntry",
    fieldbackground=PANEL2,
    foreground=TEXT,
    insertcolor=TEXT,
    bordercolor=BORDER,
    lightcolor=BORDER,
    darkcolor=BORDER,
    padding=6
)

style.configure(
    "TCombobox",
    fieldbackground=PANEL2,
    foreground=TEXT,
    selectbackground=ACCENT,
    selectforeground="#ffffff",
    bordercolor=BORDER,
    padding=5
)

style.map(
    "TCombobox",
    fieldbackground=[("readonly", PANEL2)],
    foreground=[("readonly", TEXT)]
)

style.configure(
    "Treeview",
    background=PANEL,
    fieldbackground=PANEL,
    foreground=TEXT,
    bordercolor=BORDER,
    rowheight=34,
    font=("Segoe UI", 9)
)

style.configure(
    "Treeview.Heading",
    background=PANEL2,
    foreground=MUTED,
    relief="flat",
    font=("Segoe UI", 9, "bold"),
    padding=8
)

style.map(
    "Treeview",
    background=[("selected", ACCENT)],
    foreground=[("selected", "#ffffff")]
)

style.configure(
    "Vertical.TScrollbar",
    background=PANEL2,
    troughcolor=BG,
    bordercolor=BG,
    arrowcolor=MUTED
)

sel=None
name=tk.StringVar(); status=tk.StringVar(value="Not Started"); progress=tk.IntVar(value=0)
source=tk.StringVar(value="Manual"); path=tk.StringVar(); appid=tk.StringVar()
method=tk.StringVar(value="Manual"); total=tk.IntVar(); unlocked=tk.IntVar()
search=tk.StringVar(); stats=tk.StringVar(); info=tk.StringVar()

def all_games():
    return db.execute("""SELECT id,name,status,progress,source,steam_appid,achievements_total,
        achievements_unlocked,completion_method FROM games ORDER BY name COLLATE NOCASE""").fetchall()

def refresh():
    q = search.get().strip().lower()

    # Clear the game list
    for item in tree.get_children():
        tree.delete(item)

    # Get games
    rows = db.execute("""
        SELECT
            id,
            name,
            status,
            progress,
            source,
            achievements_total,
            achievements_unlocked,
            completion_method
        FROM games
        ORDER BY name COLLATE NOCASE
    """).fetchall()

    # Add each game
    for row in rows:

        game_id = row[0]
        game_name = row[1]
        game_status = row[2]
        game_progress = row[3]
        platform = row[4]
        selected_tab = platform_tab_var.get() if "platform_tab_var" in globals() else "All"
        if selected_tab != "All" and platform != selected_tab: continue
        achievements_total = row[5]
        achievements_unlocked = row[6]
        completion_method = row[7]

        # Search
        if q:
            if (
                q not in game_name.lower()
                and q not in platform.lower()
            ):
                continue

        # Achievement text
        if achievements_total > 0:
            achievement_text = (
                str(achievements_unlocked)
                + "/"
                + str(achievements_total)
            )
        else:
            achievement_text = "—"

        # Platform icon
        icon = platform_logos.get(
            platform,
            generic_icon
        )

        # IMPORTANT:
        # values MUST be passed as a keyword argument.
        row_values = (
            game_name,
            game_status,
            str(game_progress) + "%",
            achievement_text,
            platform,
            completion_method
        )

        tree.insert(
            parent="",
            index="end",
            iid=str(game_id),
            image=icon,
            values=(
                game_name,
                game_status,
                str(game_progress) + "%",
                achievement_text,
                platform,
                completion_method
            )
        )

    # Statistics
    all_rows = db.execute("""
        SELECT status, progress
        FROM games
    """).fetchall()

    total_games = len(all_rows)

    completed_games = sum(
        1
        for status, progress_value in all_rows
        if status == "Completed" or progress_value >= 100
    )

    if total_games > 0:
        average_completion = round(
            sum(progress_value for status, progress_value in all_rows)
            / total_games
        )
    else:
        average_completion = 0

    stats.set(
        f"{completed_games}/{total_games} completed"
        f"   •   Average completion: {average_completion}%"
    )

def clear():
    global sel
    sel=None
    for v,val in [(name,""),(status,"Not Started"),(progress,0),(source,"Manual"),(path,""),
                  (appid,""),(method,"Manual"),(total,0),(unlocked,0),(info,"")]: v.set(val)
    notes.delete("1.0","end"); tree.selection_remove(tree.selection())
    try: rebuild_sidebar_fields()
    except NameError: pass

def select(event=None):
    global sel
    s=tree.selection()
    if not s:return
    sel=int(s[0])
    r=db.execute("""SELECT name,status,progress,notes,source,path,steam_appid,
      achievements_total,achievements_unlocked,completion_method FROM games WHERE id=?""",(sel,)).fetchone()
    name.set(r[0]);status.set(r[1]);progress.set(r[2]);notes.delete("1.0","end");notes.insert("1.0",r[3])
    source.set(r[4]);path.set(r[5]);appid.set(r[6]);total.set(r[7]);unlocked.set(r[8]);method.set(r[9])
    try: rebuild_sidebar_fields()
    except NameError: pass
    info.set(f"Achievements: {r[8]}/{r[7]}" if r[7] else "No achievement data yet.")

def save():
    global sel
    n=name.get().strip()
    if not n: messagebox.showwarning("Missing name","Enter a game name."); return
    try:
        p=max(0,min(100,int(progress.get()))); t=max(0,int(total.get())); u=max(0,min(t,int(unlocked.get())))
    except: messagebox.showwarning("Invalid","Progress and achievement counts must be numbers."); return
    a=round(u/t*100) if t else None
    final=a if method.get()=="Achievements" and a is not None else round((p+a)/2) if method.get()=="Combined" and a is not None else p
    st="Completed" if final>=100 else status.get()
    vals=(n,st,min(100,final),notes.get("1.0","end").strip(),source.get(),path.get(),appid.get().strip(),t,u,method.get())
    try:
        if sel:
            db.execute("""UPDATE games SET name=?,status=?,progress=?,notes=?,source=?,path=?,steam_appid=?,
              achievements_total=?,achievements_unlocked=?,completion_method=? WHERE id=?""",vals+(sel,))
        else:
            db.execute("""INSERT INTO games(name,status,progress,notes,source,path,steam_appid,
              achievements_total,achievements_unlocked,completion_method) VALUES(?,?,?,?,?,?,?,?,?,?)""",vals)
        db.commit()
    except sqlite3.IntegrityError:
        messagebox.showwarning("Already exists","That game is already tracked."); return
    refresh();clear()

def delete():
    if not sel:return
    if messagebox.askyesno("Delete","Delete the selected game?"):
        db.execute("DELETE FROM games WHERE id=?",(sel,));db.commit();refresh();clear()

def complete():
    if sel: db.execute("UPDATE games SET status='Completed',progress=100 WHERE id=?",(sel,));db.commit();refresh();select()
    else: messagebox.showinfo("Select a game","Select a game first.")

def scan_steam():
    paths=[]
    custom=get_setting("scan_Steam","").strip()
    if custom:
        paths.append(Path(custom))
    try:
        import winreg
        for hive,key in [(winreg.HKEY_CURRENT_USER,r"Software\Valve\Steam"),
                         (winreg.HKEY_LOCAL_MACHINE,r"SOFTWARE\WOW6432Node\Valve\Steam")]:
            try:
                with winreg.OpenKey(hive,key) as k: paths.append(Path(winreg.QueryValueEx(k,"SteamPath")[0]))
            except: pass
    except: pass
    for e in ("PROGRAMFILES(X86)","PROGRAMFILES"):
        if os.environ.get(e): paths.append(Path(os.environ[e])/"Steam")
    libs=[]
    for s in paths:
        v=s/"steamapps"/"libraryfolders.vdf"
        if v.exists():
            libs.append(s); txt=v.read_text(errors="ignore")
            libs += [Path(x.replace("\\\\","\\")) for x in re.findall(r'"path"\s+"([^"]+)"',txt)]
        elif (s/"steamapps").exists(): libs.append(s)
    found=0
    for lib in set(libs):
        for mf in (lib/"steamapps").glob("appmanifest_*.acf"):
            txt=mf.read_text(errors="ignore"); nm=re.search(r'"name"\s+"([^"]+)"',txt); aid=re.search(r'"appid"\s+"(\d+)"',txt)
            if not nm:continue
            before=db.total_changes
            db.execute("""INSERT OR IGNORE INTO games(name,source,path,steam_appid,completion_method)
                VALUES(?,?,?,?,?)""",(nm.group(1),"Steam",str(lib),aid.group(1) if aid else "","Achievements"))
            found += db.total_changes-before
    db.commit();refresh();messagebox.showinfo("Steam scan", f"New Steam games found: {found}")

def detect_minecraft():
    """
    Finds the installed Minecraft Launcher through Windows Start Apps
    and saves its AppID so Game Tracker can launch it directly.
    """

    try:
        result = subprocess.run(
            [
                "powershell",
                "-NoProfile",
                "-ExecutionPolicy",
                "Bypass",
                "-Command",
                "Get-StartApps | Where-Object {$_.Name -like '*Minecraft*'} | "
                "Select-Object -First 1 Name,AppID | ConvertTo-Json -Compress"
            ],
            capture_output=True,
            text=True,
            timeout=10
        )

    except Exception as error:
        messagebox.showerror(
            "Minecraft Detection",
            f"Could not search Windows apps.\n\n{error}"
        )
        return

    output = result.stdout.strip()

    if not output:
        messagebox.showwarning(
            "Minecraft",
            "Minecraft Launcher was not found in your Windows apps."
        )
        return

    try:
        data = json.loads(output)

        if isinstance(data, dict):
            app_name = data.get("Name", "")
            app_id = data.get("AppID", "")
        else:
            app_name = ""
            app_id = ""

    except Exception:
        messagebox.showerror(
            "Minecraft Detection",
            f"Windows returned an unexpected result:\n\n{output}"
        )
        return

    if not app_id:
        messagebox.showwarning(
            "Minecraft",
            "Minecraft was found, but Windows didn't provide a launch ID."
        )
        return

    existing = db.execute(
        """
        SELECT id
        FROM games
        WHERE source='Minecraft'
        """
    ).fetchone()

    if existing:

        db.execute(
            """
            UPDATE games
            SET name=?,
                path=?,
                notes=?
            WHERE id=?
            """,
            (
                "Minecraft",
                app_id,
                f"Windows App ID: {app_id}",
                existing[0]
            )
        )

    else:

        db.execute(
            """
            INSERT INTO games(
                name,
                status,
                progress,
                source,
                path,
                notes,
                completion_method
            )
            VALUES(?,?,?,?,?,?,?)
            """,
            (
                "Minecraft",
                "Not Started",
                0,
                "Minecraft",
                app_id,
                f"Windows App ID: {app_id}",
                "Manual"
            )
        )

    db.commit()
    refresh()

    messagebox.showinfo(
        "Minecraft",
        "Minecraft Launcher was found and added to Game Tracker!"
    )

def adb():
    custom=get_setting("scan_BlueStacks","").strip()
    candidates=[]
    if custom:
        cp=Path(custom)
        candidates += [cp/"HD-Adb.exe", cp/"BlueStacks_nxt"/"HD-Adb.exe", cp]
    candidates += [Path(os.environ.get("PROGRAMFILES",""))/"BlueStacks_nxt"/"HD-Adb.exe",
                    Path(os.environ.get("PROGRAMFILES(X86)",""))/"BlueStacks_nxt"/"HD-Adb.exe",
                    Path("C:/ProgramData/BlueStacks_nxt/HD-Adb.exe")]
    for p in candidates:
        if p.exists(): return p
    return None

def open_bluestacks():
    """
    Opens BlueStacks if it isn't already running.
    Does NOT try to connect to ADB.
    """

    # Already running?
    try:
        result = subprocess.run(
            ["tasklist"],
            capture_output=True,
            text=True,
            timeout=5
        )

        if "HD-Player.exe" in result.stdout:
            return True

    except Exception:
        pass

    # Normal BlueStacks locations
    locations = []
    custom=get_setting("scan_BlueStacks","").strip()
    if custom:
        cp=Path(custom)
        locations += [cp/"HD-Player.exe", cp/"BlueStacks_nxt"/"HD-Player.exe", cp]
    locations += [
        Path("C:/Program Files/BlueStacks_nxt/HD-Player.exe"),
        Path("C:/Program Files (x86)/BlueStacks_nxt/HD-Player.exe"),
    ]

    launcher = None

    for location in locations:
        if location.exists():
            launcher = location
            break

    if launcher is None:
        messagebox.showwarning(
            "BlueStacks",
            "Game Tracker couldn't find HD-Player.exe.\n\n"
            "Open BlueStacks manually once, then we can set the exact "
            "installation location."
        )
        return False

    try:
        subprocess.Popen(
            [str(launcher)],
            cwd=str(launcher.parent)
        )

        return True

    except Exception as error:
        messagebox.showerror(
            "BlueStacks Launch Error",
            f"Couldn't start BlueStacks.\n\n{error}"
        )
        return False

def scan_bluestacks():
    """
    Opens BlueStacks if needed, connects to its ADB device,
    detects installed third-party Android apps, and adds them
    to the Game Tracker.
    """

    # -------------------------------------------------
    # 1. Find BlueStacks ADB
    # -------------------------------------------------

    adb_exe = adb()

    if not adb_exe:
        messagebox.showwarning(
            "BlueStacks",
            "Could not find BlueStacks HD-Adb.exe.\n\n"
            "The normal location is:\n"
            "C:\\Program Files\\BlueStacks_nxt\\HD-Adb.exe"
        )
        return

    # -------------------------------------------------
    # 2. Open BlueStacks if it is not already running
    # -------------------------------------------------

    try:
        tasklist = subprocess.run(
            ["tasklist"],
            capture_output=True,
            text=True,
            timeout=5
        )

        if "HD-Player.exe" not in tasklist.stdout:

            bluestacks_locations = [
                Path(
                    "C:/Program Files/BlueStacks_nxt/HD-Player.exe"
                ),
                Path(
                    "C:/Program Files (x86)/BlueStacks_nxt/HD-Player.exe"
                ),
            ]

            launcher = None

            for location in bluestacks_locations:
                if location.exists():
                    launcher = location
                    break

            if launcher is None:
                messagebox.showwarning(
                    "BlueStacks",
                    "BlueStacks was not found."
                )
                return

            subprocess.Popen(
                [str(launcher)],
                cwd=str(launcher.parent)
            )

    except Exception as error:
        messagebox.showerror(
            "BlueStacks",
            f"Could not start BlueStacks.\n\n{error}"
        )
        return

    # -------------------------------------------------
    # 3. Try to find the connected ADB device
    # -------------------------------------------------

    import time

    connected_device = None

    # Give BlueStacks a moment to start its Android instance.
    for _ in range(15):

        try:
            result = subprocess.run(
                [
                    str(adb_exe),
                    "devices"
                ],
                capture_output=True,
                text=True,
                timeout=5
            )

            for line in result.stdout.splitlines():

                line = line.strip()

                if not line or line.startswith("List of devices"):
                    continue

                parts = line.split()

                if len(parts) >= 2:

                    device = parts[0]
                    state = parts[1]

                    if state == "device":
                        connected_device = device
                        break

            if connected_device:
                break

        except Exception:
            pass

        time.sleep(1)

    # -------------------------------------------------
    # 4. If no device is connected, try common ports
    # -------------------------------------------------

    if not connected_device:

        ports = [
            5555,
            5565,
            5575,
            5585,
            5595,
            5605,
            5615,
            5625
        ]

        for port in ports:

            address = f"127.0.0.1:{port}"

            try:
                subprocess.run(
                    [
                        str(adb_exe),
                        "connect",
                        address
                    ],
                    capture_output=True,
                    text=True,
                    timeout=5
                )

                result = subprocess.run(
                    [
                        str(adb_exe),
                        "devices"
                    ],
                    capture_output=True,
                    text=True,
                    timeout=5
                )

                for line in result.stdout.splitlines():

                    line = line.strip()

                    if address in line and "\tdevice" in line:
                        connected_device = address
                        break

                if connected_device:
                    break

            except Exception:
                continue

    # -------------------------------------------------
    # 5. Still not connected
    # -------------------------------------------------

    if not connected_device:

        messagebox.showwarning(
            "BlueStacks ADB",
            "BlueStacks opened, but Game Tracker couldn't connect "
            "to its Android instance.\n\n"
            "Make sure this is enabled:\n\n"
            "BlueStacks → Settings → Advanced → "
            "Android Debug Bridge"
        )

        return

    # -------------------------------------------------
    # 6. Get installed third-party Android packages
    # -------------------------------------------------

    try:

        result = subprocess.run(
            [
                str(adb_exe),
                "-s",
                connected_device,
                "shell",
                "pm",
                "list",
                "packages",
                "-3"
            ],
            capture_output=True,
            text=True,
            timeout=15
        )

    except Exception as error:

        messagebox.showerror(
            "BlueStacks",
            f"Could not read installed apps.\n\n{error}"
        )

        return

    packages = []

    for line in result.stdout.splitlines():

        line = line.strip()

        if line.startswith("package:"):

            package = line.replace(
                "package:",
                "",
                1
            ).strip()

            if package:
                packages.append(package)

    if not packages:

        messagebox.showinfo(
            "BlueStacks",
            "Connected to BlueStacks, but no third-party "
            "Android apps were detected."
        )

        return

    # -------------------------------------------------
    # 7. Add games to Game Tracker
    # -------------------------------------------------

    new_games = 0
    repaired_games = 0

    for package in packages:

        # Default name is package name.
        game_name = package

        # Try to get the friendly Android app name.
        try:

            dump = subprocess.run(
                [
                    str(adb_exe),
                    "-s",
                    connected_device,
                    "shell",
                    "dumpsys",
                    "package",
                    package
                ],
                capture_output=True,
                text=True,
                timeout=8
            )

            match = re.search(
                r"application-label(?:-en)?=(.+)",
                dump.stdout
            )

            if match:

                detected_name = match.group(1).strip()

                if detected_name:
                    game_name = detected_name

        except Exception:
            pass

        # -------------------------------------------------
        # Check if this package already exists
        # -------------------------------------------------

        existing = db.execute(
            """
            SELECT id, path
            FROM games
            WHERE source='BlueStacks'
            AND (
                path=?
                OR notes LIKE ?
            )
            """,
            (
                package,
                f"%Android package: {package}%"
            )
        ).fetchone()

        # -------------------------------------------------
        # Repair an existing game
        # -------------------------------------------------

        if existing:

            game_id = existing[0]

            db.execute(
                """
                UPDATE games
                SET path=?,
                    notes=?
                WHERE id=?
                """,
                (
                    package,
                    f"Android package: {package}",
                    game_id
                )
            )

            repaired_games += 1

        # -------------------------------------------------
        # Add new game
        # -------------------------------------------------

        else:

            try:

                db.execute(
                    """
                    INSERT INTO games(
                        name,
                        status,
                        progress,
                        source,
                        path,
                        notes,
                        completion_method
                    )
                    VALUES(
                        ?,
                        ?,
                        ?,
                        ?,
                        ?,
                        ?,
                        ?
                    )
                    """,
                    (
                        game_name,
                        "Not Started",
                        0,
                        "BlueStacks",
                        package,
                        f"Android package: {package}",
                        "Manual"
                    )
                )

                new_games += 1

            except sqlite3.IntegrityError:

                # If the friendly name already exists, add the
                # package to the existing matching BlueStacks game.
                existing_name = db.execute(
                    """
                    SELECT id
                    FROM games
                    WHERE name=?
                    AND source='BlueStacks'
                    """,
                    (game_name,)
                ).fetchone()

                if existing_name:

                    db.execute(
                        """
                        UPDATE games
                        SET path=?,
                            notes=?
                        WHERE id=?
                        """,
                        (
                            package,
                            f"Android package: {package}",
                            existing_name[0]
                        )
                    )

    db.commit()

    # -------------------------------------------------
    # 8. Update the UI
    # -------------------------------------------------

    refresh()

    messagebox.showinfo(
        "BlueStacks Scan Complete",
        f"Connected device:\n{connected_device}\n\n"
        f"Android apps found: {len(packages)}\n"
        f"New games added: {new_games}\n"
        f"Existing games updated: {repaired_games}"
    )

def detect_roblox():
    """
    Finds the installed Roblox Windows app and saves its AUMID
    in the Install Path field.
    """

    try:
        result = subprocess.run(
            [
                "powershell",
                "-NoProfile",
                "-ExecutionPolicy",
                "Bypass",
                "-Command",
                "Get-StartApps | Where-Object {$_.Name -like '*Roblox*'} | "
                "Select-Object -First 1 Name,AppID | ConvertTo-Json -Compress"
            ],
            capture_output=True,
            text=True,
            timeout=10
        )

    except Exception as error:
        messagebox.showerror(
            "Roblox Detection",
            f"Could not search Windows apps.\n\n{error}"
        )
        return

    output = result.stdout.strip()

    if not output:
        messagebox.showwarning(
            "Roblox",
            "Roblox was not found in your Windows apps."
        )
        return

    try:
        data = json.loads(output)

        # PowerShell can return a dictionary for one result.
        if isinstance(data, dict):
            app_name = data.get("Name", "")
            app_id = data.get("AppID", "")
        else:
            app_name = ""
            app_id = ""

    except Exception:
        messagebox.showerror(
            "Roblox Detection",
            f"Windows returned an unexpected result:\n\n{output}"
        )
        return

    if not app_id:
        messagebox.showwarning(
            "Roblox",
            "Roblox was found, but Windows did not provide a launch ID."
        )
        return

    # See whether Roblox is already tracked.
    existing = db.execute(
        """
        SELECT id
        FROM games
        WHERE source='Roblox'
        """
    ).fetchone()

    if existing:
        db.execute(
            """
            UPDATE games
            SET name=?,
                path=?,
                notes=?
            WHERE id=?
            """,
            (
                "Roblox",
                app_id,
                f"Windows App ID: {app_id}",
                existing[0]
            )
        )

        db.commit()
        refresh()

        messagebox.showinfo(
            "Roblox",
            "Roblox was found and its launch information was updated."
        )

    else:
        db.execute(
            """
            INSERT INTO games(
                name,
                status,
                progress,
                source,
                path,
                notes,
                completion_method
            )
            VALUES(?,?,?,?,?,?,?)
            """,
            (
                "Roblox",
                "Not Started",
                0,
                "Roblox",
                app_id,
                f"Windows App ID: {app_id}",
                "Manual"
            )
        )

        db.commit()
        refresh()

        messagebox.showinfo(
            "Roblox",
            "Roblox was found and added to Game Tracker!"
        )


    db.commit()
    refresh()

    messagebox.showinfo(
        "Roblox",
        "Roblox was added to your game tracker!"
    )

def settings():
    f=APP/"steam_settings.txt"
    if not f.exists():return None,"Create steam_settings.txt with API_KEY=... and STEAM_ID=..."
    d={}
    for line in f.read_text(errors="ignore").splitlines():
        if "=" in line:k,v=line.split("=",1);d[k.strip()]=v.strip()
    if not d.get("API_KEY") or not d.get("STEAM_ID"):return None,"steam_settings.txt needs API_KEY and STEAM_ID."
    return (d["API_KEY"],d["STEAM_ID"]),None

def steam_data(aid):
    s,e=settings()
    if e:return None,e
    key,sid=s
    url="https://api.steampowered.com/ISteamUserStats/GetPlayerAchievements/v1/?"+urllib.parse.urlencode({"key":key,"steamid":sid,"appid":aid})
    try:
        with urllib.request.urlopen(url,timeout=15) as r:return json.loads(r.read()),None
    except Exception as e:return None,str(e)

ASSETS = APP / "assets"

platform_logos = {}

def load_platform_logos():
    logo_files = {
        "Steam": "steam.png",
        "Minecraft": "minecraft.png",
        "Roblox": "roblox.png",
        "BlueStacks": "bluestacks.png"
    }

    for platform, filename in logo_files.items():

        file_path = ASSETS / filename

        if not file_path.exists():
            print("Missing:", file_path)
            continue

        try:
            # Tkinter can load PNG files directly.
            logo = tk.PhotoImage(file=str(file_path))

            # Scale larger images down.
            width = logo.width()
            height = logo.height()

            if width > 32 or height > 32:
                factor = max(
                    1,
                    max(width // 28, height // 28)
                )

                logo = logo.subsample(factor, factor)

            platform_logos[platform] = logo

            print("Loaded icon:", platform)

        except Exception as error:
            print("Icon error:", platform, error)

load_platform_logos()

try:
    generic_icon = tk.PhotoImage(file=str(ASSETS / "generic.png"))
except Exception:
    generic_icon = tk.PhotoImage(width=32,height=32)

try:
    icon_file = APP / "game_tracker.ico"
    if icon_file.exists():
        root.iconbitmap(default=str(icon_file))
except Exception:
    pass

def update_one():
    if not sel:messagebox.showinfo("Select a game","Select a Steam game first.");return
    r=db.execute("SELECT source,steam_appid FROM games WHERE id=?",(sel,)).fetchone()
    if not r or r[0]!="Steam" or not r[1]:messagebox.showinfo("Steam game","Select a detected Steam game.");return
    info.set("Updating Steam achievements...");root.update_idletasks()
    data,e=steam_data(r[1])
    if e:messagebox.showerror("Steam API",e);return
    ach=(data or {}).get("playerstats",{}).get("achievements",[])
    if not ach:messagebox.showwarning("No data","Steam returned no achievement data for this game.");return
    u=sum(x.get("achieved")==1 for x in ach);t=len(ach);p=round(u/t*100)
    st="Completed" if p==100 else ("Playing" if u else "Not Started")
    db.execute("""UPDATE games SET achievements_total=?,achievements_unlocked=?,progress=?,status=?,completion_method='Achievements' WHERE id=?""",(t,u,p,st,sel))
    db.commit();refresh();select();info.set(f"Steam updated: {u}/{t} ({p}%)")

def update_all():
    rows=[r for r in all_games() if r[4]=="Steam" and r[5]]
    if not rows:messagebox.showinfo("Steam","No detected Steam games with AppIDs.");return
    def work():
        count=0
        for r in rows:
            data,e=steam_data(r[5])
            ach=(data or {}).get("playerstats",{}).get("achievements",[]) if data else []
            if ach:
                u=sum(x.get("achieved")==1 for x in ach);t=len(ach);p=round(u/t*100);st="Completed" if p==100 else ("Playing" if u else "Not Started")
                db.execute("""UPDATE games SET achievements_total=?,achievements_unlocked=?,progress=?,status=?,completion_method='Achievements' WHERE id=?""",(t,u,p,st,r[0]));db.commit();count+=1
        root.after(0,lambda:(refresh(),info.set(f"Updated {count}/{len(rows)} Steam games.")))
    threading.Thread(target=work,daemon=True).start();info.set("Updating Steam achievements...")


def browse_folder(var):
    from tkinter import filedialog
    folder=filedialog.askdirectory()
    if folder: var.set(folder)

def open_settings():
    win=tk.Toplevel(root); win.title("Game Tracker Settings"); win.geometry("620x560"); win.configure(bg=BG); win.transient(root); win.grab_set()
    ttk.Label(win,text="⚙ Settings",style="Title.TLabel").pack(anchor="w",padx=22,pady=(18,4))
    ttk.Label(win,text="Customize appearance and scan locations.",style="Subtitle.TLabel").pack(anchor="w",padx=22)
    app=ttk.LabelFrame(win,text="Appearance",padding=14); app.pack(fill="x",padx=22,pady=18)
    theme_var=tk.StringVar(value=current_theme.title()); ttk.Label(app,text="Theme").pack(side="left"); ttk.Combobox(app,textvariable=theme_var,values=("Dark","Light"),state="readonly",width=14).pack(side="left",padx=12)
    def apply_and_close():
        n=theme_var.get().lower(); set_setting("theme",n); apply_theme(n); win.destroy()
    ttk.Button(app,text="Apply",command=apply_and_close,style="Accent.TButton").pack(side="right")
    box=ttk.LabelFrame(win,text="Scan paths",padding=14); box.pack(fill="both",expand=True,padx=22,pady=(0,18))
    vars={}
    labels={"Steam":"Steam library root","Minecraft":"Minecraft folder","Roblox":"Roblox search override","BlueStacks":"BlueStacks folder"}
    for key in ("Steam","Minecraft","Roblox","BlueStacks"):
        row=ttk.Frame(box); row.pack(fill="x",pady=6); ttk.Label(row,text=labels[key],width=21).pack(side="left")
        v=tk.StringVar(value=get_setting("scan_"+key,"")); vars[key]=v
        ttk.Entry(row,textvariable=v).pack(side="left",fill="x",expand=True,padx=8); ttk.Button(row,text="Browse",command=lambda vv=v:browse_folder(vv)).pack(side="right")
    ttk.Label(box,text="Roblox normally uses Windows app discovery; its path field can stay blank.",style="Subtitle.TLabel").pack(anchor="w",pady=(8,0))
    def save_paths():
        for k,v in vars.items(): set_setting("scan_"+k,v.get().strip())
        win.destroy()
    ttk.Button(win,text="Save Scan Settings",command=save_paths,style="Accent.TButton").pack(pady=(0,18))

# UI
h=ttk.Frame(root,padding=(22,18,22,10)); h.pack(fill="x")
title=ttk.Frame(h); title.pack(fill="x"); ttk.Label(title,text="🎮  GAME TRACKER",style="Title.TLabel").pack(side="left"); ttk.Button(title,text="⚙ Settings",command=open_settings).pack(side="right")
ttk.Label(h,text="Your games. Your progress. One dashboard.",style="Subtitle.TLabel").pack(anchor="w",pady=(2,0)); ttk.Label(h,textvariable=stats,style="Stats.TLabel").pack(anchor="w",pady=(7,0))

b=ttk.Frame(root,padding=(22,7)); b.pack(fill="x"); ttk.Label(b,text="Search:").pack(side="left"); search_entry=ttk.Entry(b,textvariable=search,width=30); search_entry.pack(side="left",padx=7); search_entry.bind("<KeyRelease>",lambda e:refresh())
for label,cmd in [("Scan Steam",scan_steam),("Scan Roblox",detect_roblox),("Scan Minecraft",detect_minecraft),("Scan BlueStacks Games",scan_bluestacks)]: ttk.Button(b,text=label,command=cmd).pack(side="right",padx=3)

platform_tab_var=tk.StringVar(value="All"); tabs=ttk.Notebook(root); tabs.pack(fill="x",padx=22,pady=(3,8))
for tab_name in ("All","Steam","Minecraft","Roblox","BlueStacks","Manual"):
    tabs.add(ttk.Frame(tabs),text=tab_name)
tabs.bind("<<NotebookTabChanged>>",lambda e:(platform_tab_var.set(tabs.tab(tabs.select(),"text")),refresh()))

main=ttk.Frame(root,padding=(22,8,22,18)); main.pack(fill="both",expand=True); left=ttk.Frame(main); left.pack(side="left",fill="both",expand=True)
ttk.Label(left,text="LIBRARY",foreground=MUTED,background=BG,font=("Segoe UI",9,"bold")).pack(anchor="w",pady=(0,6))
tree=ttk.Treeview(left,columns=("game","status","completion","ach","platform","method"),show="tree headings"); tree.heading("#0",text=""); tree.column("#0",width=50,minwidth=50,stretch=False)
for c,tv in [("game","Game"),("status","Status"),("completion","Completion"),("ach","Achievements"),("platform","Platform"),("method","Method")]: tree.heading(c,text=tv)
for c,w in [("game",250),("status",105),("completion",100),("ach",110),("platform",110),("method",105)]: tree.column(c,width=w)
ys=ttk.Scrollbar(left,orient="vertical",command=tree.yview); tree.configure(yscrollcommand=ys.set); tree.pack(side="left",fill="both",expand=True); ys.pack(side="right",fill="y"); tree.bind("<<TreeviewSelect>>",select)

outer=ttk.Frame(main); outer.pack(side="right",fill="y",padx=(16,0)); canvas=tk.Canvas(outer,width=365,highlightthickness=0,bg=BG,bd=0); side_scrollbar=ttk.Scrollbar(outer,orient="vertical",command=canvas.yview); canvas.configure(yscrollcommand=side_scrollbar.set); side_scrollbar.pack(side="right",fill="y"); canvas.pack(side="left",fill="y",expand=True)
panel=ttk.LabelFrame(canvas,text="Game details",padding=14); panel_window=canvas.create_window((0,0),window=panel,anchor="nw",width=365); panel.bind("<Configure>",lambda e:canvas.configure(scrollregion=canvas.bbox("all"))); canvas.bind("<Configure>",lambda e:canvas.itemconfig(panel_window,width=e.width))

def side_mousewheel(event):
    try:
        x=canvas.winfo_pointerx(); y=canvas.winfo_pointery(); rx=canvas.winfo_rootx(); ry=canvas.winfo_rooty()
        if rx<=x<=rx+canvas.winfo_width() and ry<=y<=ry+canvas.winfo_height():
            if getattr(event,"delta",0): canvas.yview_scroll(-1 if event.delta>0 else 1,"units")
            elif getattr(event,"num",None)==4: canvas.yview_scroll(-1,"units")
            elif getattr(event,"num",None)==5: canvas.yview_scroll(1,"units")
    except Exception: pass
root.bind_all("<MouseWheel>",side_mousewheel,add="+"); root.bind_all("<Button-4>",side_mousewheel,add="+"); root.bind_all("<Button-5>",side_mousewheel,add="+")

def rebuild_sidebar_fields():
    for w in list(panel.winfo_children()):
        if getattr(w,"dynamic_field",False): w.destroy()
    src=source.get()
    def add(label,var):
        lab=ttk.Label(panel,text=label); lab.dynamic_field=True; lab.pack(anchor="w")
        ent=ttk.Entry(panel,textvariable=var,width=38); ent.dynamic_field=True; ent.pack(fill="x",pady=(4,10))
    if src=="Steam": add("Steam AppID",appid); add("Steam Library Path",path)
    elif src in ("Minecraft","Roblox"): add("Windows App ID",path)
    elif src=="BlueStacks": add("Android Package",path)
    else: add("Install / Launch Path",path)

name_label=ttk.Label(panel,text="Game name"); name_label.pack(anchor="w"); ttk.Entry(panel,textvariable=name,width=38).pack(fill="x",pady=(4,10))
source_label=ttk.Label(panel,text="Platform / source"); source_label.pack(anchor="w"); ttk.Combobox(panel,textvariable=source,values=("Manual","Steam","Minecraft","Roblox","BlueStacks"),state="readonly",width=35).pack(fill="x",pady=(4,10)); source.trace_add("write",lambda *a:rebuild_sidebar_fields()); rebuild_sidebar_fields()
ttk.Label(panel,text="Status").pack(anchor="w"); ttk.Combobox(panel,textvariable=status,values=("Not Started","Playing","Completed"),state="readonly",width=35).pack(fill="x",pady=(4,10))
ttk.Label(panel,text="Completion method").pack(anchor="w"); ttk.Combobox(panel,textvariable=method,values=("Manual","Achievements","Combined"),state="readonly",width=35).pack(fill="x",pady=(4,10))
ttk.Label(panel,text="Manual completion (0–100%)").pack(anchor="w"); ttk.Spinbox(panel,from_=0,to=100,textvariable=progress,width=8).pack(anchor="w",pady=(4,10))
ttk.Label(panel,text="Achievements unlocked / total").pack(anchor="w"); ar=ttk.Frame(panel); ar.pack(fill="x",pady=(4,10)); ttk.Spinbox(ar,from_=0,to=9999,textvariable=unlocked,width=10).pack(side="left"); ttk.Label(ar,text=" / ").pack(side="left"); ttk.Spinbox(ar,from_=0,to=9999,textvariable=total,width=10).pack(side="left")
ttk.Button(panel,text="🔄 Update Selected Steam",command=update_one).pack(fill="x",pady=3); ttk.Label(panel,textvariable=info,wraplength=325).pack(anchor="w",pady=6); ttk.Label(panel,text="Notes").pack(anchor="w")
notes=tk.Text(panel,width=38,height=7,wrap="word",bg=PANEL2,fg=TEXT,insertbackground=TEXT,selectbackground=ACCENT,selectforeground="#ffffff",relief="flat",bd=0,padx=8,pady=8,font=("Segoe UI",9)); notes.pack(fill="both",expand=True,pady=(4,12))
ttk.Button(panel,text="▶  Launch Game",command=launch_game,style="Accent.TButton").pack(fill="x",pady=4)
for txt,cmd in [("✓ Mark Completed",complete),("💾 Save Game",save),("➕ New / Clear",clear),("🗑 Delete",delete)]: ttk.Button(panel,text=txt,command=cmd).pack(fill="x",pady=3)
ttk.Label(root,text="●  Use the tabs to filter platforms  •  Hover over the details panel and use the mouse wheel to scroll",style="Subtitle.TLabel",padding=(22,2,22,12)).pack(anchor="w")

try:
    if generic_icon is not None: root.iconphoto(True,generic_icon)
except Exception: pass

refresh();root.mainloop()
