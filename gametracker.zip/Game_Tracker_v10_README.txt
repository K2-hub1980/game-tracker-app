GAME TRACKER v10

Implemented from your uploaded v9:
1. Platform tabs: All, Steam, Minecraft, Roblox, BlueStacks, Manual.
2. Settings menu: Dark/Light theme plus scan-path fields saved locally.
3. Contextual sidebar fields:
   - Steam: Steam AppID + Steam library path
   - Minecraft/Roblox: Windows App ID
   - BlueStacks: Android Package
   - Manual: Install / Launch Path
4. Controller-style generic icon for entries without a platform icon.
5. .pyw + VBS launchers to hide the CMD window.
6. Controller icon is also used as the running app/window icon when available.
7. Mouse-wheel scrolling works anywhere while the pointer is over the right details panel.
8. Custom Steam, Minecraft, and BlueStacks scan paths are now read from Settings.

IMPORTANT:
Copy Game_Tracker_v10.py (or .pyw), game_tracker.ico, and the assets folder into the
same folder as your existing games.db to keep your current library. The settings table
is added automatically.

No terminal:
double-click Game_Tracker_v10.pyw or launch_Game_Tracker_hidden.vbs
